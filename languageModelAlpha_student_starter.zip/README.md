# Build Language Model Alpha

Your goal is a program that reads a text file and generates one sentence by randomly choosing tokens from that file. Use only Python's standard library.

Implement the functions during class, following the instructor's guidance. Keep the function names and parameters as provided.

## Working directory

Open your terminal in this folder, the one containing the `languageModelAlpha` directory. Use `python3` wherever the examples say `python` if necessary.

The input separates punctuation with spaces: `one fish .`. Your tokenizer only needs to split on whitespace. Preserve repeated tokens.

## 1. Tokenize lines

Implement `tokenExtractor(lines)` in `tokenExtractor.py`.

In a Python interpreter started from this folder:

```python
from languageModelAlpha.tokenExtractor import tokenExtractor

tokenExtractor(["one fish .\n", "two fish .\n"])
# Expected: ['one', 'fish', '.', 'two', 'fish', '.']

tokenExtractor([])
# Expected: []
```

Explain why the returned list should contain duplicate tokens, and why `extend` is useful here.

## 2. Generate a sentence

Implement `genSentence(tokens)` in `sentGenerator.py`.

```python
from languageModelAlpha.sentGenerator import genSentence

genSentence(["fish", "."])
# A string ending with a period; its exact contents can vary.

genSentence(["."])
# Expected: '.'

genSentence([])
# Expected: ''

genSentence(["fish"])
# Expected: 50 copies of 'fish', separated by spaces, followed by ' .'
```

Make at most 50 random choices. If the last token is not a period, append a period afterward. Return a string; do not print inside this function.

Explain why the loop needs a limit even though it stops when it selects a period.

## 3. Read arguments and connect the functions

Implement `get_filename()` and `main()` in `cli.py`.

- Use `argparse` to define one required positional argument named `filename`.
- In `main()`, get the filename, open that file, and read its lines.
- Call your two helper functions in order.
- Print the final sentence.

Keep file reading and function calls inside `main()`, rather than at the module's top level.

After finishing `get_filename()`, start a fresh Python interpreter from this folder:

```python
from languageModelAlpha.cli import get_filename

get_filename()
# Expected: argparse shows usage and an error for the missing filename,
# then raises SystemExit with code 2. This is the missing-argument check.
```

Restart the interpreter when you change imported files; an ordinary repeated `import` does not reload an already-imported module.

## 4. Add the package entry point

Finish `__main__.py`: import `main` from `.cli`, then call it inside the usual `if __name__ == "__main__":` block.

From your terminal, outside the Python interpreter:

```bash
python -m languageModelAlpha languageModelAlpha/fish.txt
python -m languageModelAlpha --help
python -m languageModelAlpha
```

The first command should print a random sentence. The second should show help. The third should show an error explaining that `filename` is required.

## Before you finish

Be ready to explain:

1. What is passed into each function, and what comes back?
2. Why does a common input token appear more often in the generated text?
3. Why is the output not guaranteed to follow the input's word order?
4. Why does `main()` handle printing while `genSentence()` returns a string?
5. Why can importing the completed helper modules leave the program idle?
