import argparse

from .tokenExtractor import tokenExtractor
from .sentGenerator import genSentence


def get_filename():
    """Return the required filename supplied at the command line."""
    # Create an ArgumentParser with a description.
    # Add one required positional argument named "filename".
    # Parse the arguments and return the filename attribute.
    raise NotImplementedError("Implement get_filename during class.")


def main():
    """Read the input file, build the token list, and print one sentence."""
    # Get the filename.
    # Open the file for reading and read its lines.
    # Pass those lines to tokenExtractor.
    # Pass the returned token list to genSentence.
    # Print the returned sentence.
    raise NotImplementedError("Implement main during class.")
