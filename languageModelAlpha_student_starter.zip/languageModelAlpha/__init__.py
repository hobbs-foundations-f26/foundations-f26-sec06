"""A minimal language model for Foundations of Business Programming."""
