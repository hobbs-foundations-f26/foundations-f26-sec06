def tokenExtractor(lines):
    """Return one flat list of whitespace-separated tokens from the lines."""
    # Start an empty list.
    # Split each line and extend the list with its tokens.
    # Preserve duplicates and return the finished list.
    raise NotImplementedError("Implement tokenExtractor during class.")
