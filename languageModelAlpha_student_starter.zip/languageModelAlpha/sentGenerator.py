import random


def genSentence(tokens):
    """Return a random sentence, or an empty string when tokens is empty."""
    # Handle an empty token list before trying to choose from it.
    # Start an empty sentence list.
    # Choose and append tokens until you pick "." or make 50 choices.
    # If needed, append a final period after the loop.
    # Join the sentence list into a string with spaces and return it.
    raise NotImplementedError("Implement genSentence during class.")
