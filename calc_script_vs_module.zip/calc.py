author = "Alice"

def sum(a,b,*args):
    return_val = a+b
    for arg in args:
        return_val += arg
    
    return return_val

# NOTE: The below lines run no matter whether the file is run as a script or imported as a module.
print(f'{sum(3,4,56)=}')


def product(a,b,*args):
    return_val = a*b
    for arg in args:
        return_val *= arg
    
    return return_val

# NOTE: The if __name__ == '__main__': block runs only when the file is run as a script, not when it is imported as a module.
if __name__ == '__main__':
    print(f'{sum(3,4)=}')
    print(f'{sum(3,4,5,6,7,8)=}')
    print(f'{product(3,4)=}')
    print(f'{product(3,4,5,6,7,8)=}')
